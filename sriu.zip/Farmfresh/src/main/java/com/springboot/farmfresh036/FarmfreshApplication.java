package com.springboot.farmfresh036;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmfreshApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmfreshApplication.class, args);
	}

}

package com.springboot.farmfresh036.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.springboot.farmfresh036.model.Customer;
import com.springboot.farmfresh036.model.Product;

@Repository
public class CustomerDao {
	@Autowired
	private JdbcTemplate jdbc;
	@Autowired
	Product cart;
	List<Product> productlist;

	public List<Product> viewProducts() {

		String sql = "select * from productlist order by category asc;" ;
		productlist = jdbc.query(sql, BeanPropertyRowMapper.newInstance(Product.class));
		System.out.println(productlist);
		return productlist;

	}
	public List<Product> addProductDetails(String email,int item_no) {

		System.out.println(email);
		System.out.println(item_no);
		String sql = "select * from productlist where item_no='" + item_no + "';";
		List<Product> items = jdbc.query(sql, BeanPropertyRowMapper.newInstance(Product.class));
		System.out.println(items);
	   Product cart=items.get(0);
		String sql1="insert into cartdetails(item_no,item_name,quantity,price,category,email)values(?,?,?,?,?,?)";
	    jdbc.update(sql1,cart.getItem_name(),item_no,cart.getQuantity(),cart.getPrice(),cart.getCategory(),email); 
		return items;

	}


	public void createNewUser(Customer customer) {

		String sql = "insert into customerdetails(name,email,password) values(?,?,?)";
		jdbc.update(sql, customer.getName(), customer.getEmail(), customer.getPassword());

	}

	public List<Customer> checkUser(String email, String password) {

		try {

			String sql = "select * from customerdetails where email='" + email + "';";
			List<Customer> cusdetail = jdbc.query(sql, BeanPropertyRowMapper.newInstance(Customer.class));
			return cusdetail;

		} catch (Exception e) {
			System.out.println(e);
		}
		return null;

	}
}




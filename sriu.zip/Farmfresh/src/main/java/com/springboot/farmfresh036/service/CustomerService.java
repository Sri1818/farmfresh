package com.springboot.farmfresh036.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.springboot.farmfresh036.dao.CustomerDao;
import com.springboot.farmfresh036.model.Customer;
import com.springboot.farmfresh036.model.Product;

@Service
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	public List<Product> viewProducts() {
		return customerDao.viewProducts();
	}
	public List<Product> addProductDetails(String email,int item_no) {
		return customerDao.addProductDetails(email, item_no);
	}
	public void createNewUser(Customer customer) {
		 customerDao.createNewUser(customer);
	}
	public List<Customer> checkUser(String email, String password) {
		return customerDao.checkUser(email, password);
	}

}

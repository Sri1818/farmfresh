package com.springboot.farmfresh036.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.farmfresh036.dao.AdminDao;

@Service
public class AdminService {
	@Autowired
	AdminDao adminDao;
	public boolean validateUser(String user_name, String password)
	{
		return AdminDao.validateUser(user_name, password);
	}


}

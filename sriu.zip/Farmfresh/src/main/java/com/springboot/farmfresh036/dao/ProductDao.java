package com.springboot.farmfresh036.dao;

import java.util.List;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.springboot.farmfresh036.model.Cart;
import com.springboot.farmfresh036.model.Product;

@Repository
public class ProductDao {
	@Autowired
	private JdbcTemplate jdbctemplate;
	@Autowired
	Product products;
	@Autowired
	Cart cart1;
	List<Product> productlist;
	
	public List<Product> viewProducts() {

		String sql = "select * from productlist;";
		productlist = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Product.class));
		return productlist;

	}
	
	public void addProducts(Product products) {

		String sql = "insert into productlist(item_no,item_name,quantity,price,category) values(?,?,?,?,?)";
		jdbctemplate.update(sql, products.getItem_no(), products.getItem_name(), products.getQuantity(),
				products.getPrice(), products.getCategory());
	}

	public void deleteProduct(int item_no) {

		String sql = "delete from productlist where item_no=?";
		jdbctemplate.update(sql, item_no);

	}
	public void deleteProduct(int item_no,String email) {

		String sql = "delete from cartdetails where item_no=? and email=?";
		jdbctemplate.update(sql, item_no,email);

	}
	public  List<Cart> retrieveCartDetails(int item_no,String useremail) {
		String sql = "select * from cartdetails where email='" + useremail + "' and item_no='" + item_no + "';";
		List<Cart> cartlist = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Cart.class));
		return cartlist;
		
	}
	public List<Cart> deleteProductPage(int item_no,int cquantity,int cprice, String useremail) {
		List<Cart> cartlist=retrieveCartDetails(item_no,useremail);
		cart1=cartlist.get(0);
		String sql = "select * from cartdetails where item_no='" + item_no + "' and email='"+useremail+"';";
		List<Cart> items = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Cart.class));
	  Cart cart1=items.get(0);
  
		System.out.println(cquantity);
		System.out.println(cprice);
		System.out.println("service");
		
	    String sql2="update cartdetails set quantity="+cart1.getQuantity()+"-"+cquantity+", price="+cart1.getPrice()+"-"+cprice+" where item_no='"+item_no+"' and email='"+useremail+"';";
		System.out.println("pass");
	    jdbctemplate.update(sql2);
	    List<Cart> cartlist1=retrieveCartDetails(item_no,useremail);
	    return cartlist1;
	    

	}
	public List<Product> retrieveProductDetails(int item_no) {

		String sql = "select * from productlist where item_no='" + item_no + "';";
		List<Product> items = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Product.class));
		return items;

	}
	public  List<Cart> retrieveCartDetailsemail(String useremail) {
		String sql = "select * from cartdetails where email='" + useremail + "'  order by category asc;";
		List<Cart> cartlist = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Cart.class));
		return cartlist;	
	}
	public void update(int item_no,String item_name,int quantity,int price,String category) {
		System.out.println(item_name);
		System.out.println(price);
		System.out.println(category);
		System.out.println(quantity);
		 String sql="update productlist set item_name='"+item_name+"',quantity='"+quantity+"',price='"+price+"',category='"+category+"' where item_no='"+item_no+"' ;";
		//String sql = "insert into productlist(item_no,item_name,quantity,price,category) values(?,?,?,?,?)";
		jdbctemplate.update(sql);
	}
	
	public List<Product> addProductDetails(int item_no,String useremail) {
		
		System.out.println(useremail);
		List<Product> product=retrieveProductDetails(item_no);
		System.out.println("hi");
		Product products=product.get(0);
		System.out.println("hi1");
		String sql = "select * from productlist where item_no='" + item_no + "';";
		List<Product> items = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Product.class));
		System.out.println(items);
	    Product cart = items.get(0);
	    List<Cart> cartlist= retrieveCartDetails( item_no, useremail);
	   System.out.println("y");
System.out.println(useremail);
	if(cartlist.isEmpty()) 
	{
		 String sql1="insert into cartdetails(item_no,item_name,quantity,price,category,email) values(?,?,?,?,?,?)";
		    jdbctemplate.update(sql1,item_no,cart.getItem_name(),cart.getQuantity(),cart.getPrice(),cart.getCategory(),useremail);
		    System.out.println(items);
		    return items;
	}
	 if(cart.getItem_no()==item_no  || cart1.getEmail()==useremail)
	  {
	  	
	  	System.out.println(products.getQuantity());
	  	System.out.println(products.getPrice());
	  	String sql2="update cartdetails set quantity='"+products.getQuantity()+"'+quantity, price='"+products.getPrice()+"'+price where item_no='"+item_no+"' and email='"+useremail+"';";
	  	jdbctemplate.update(sql2);	
	  	return items;
	  }	

		return items;
	}
	public void insertcart(int item_no,String useremail) {
		String sql = "select * from productlist where item_no='" + item_no + "';";
		List<Product> items = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Product.class));
		System.out.println(items);
	    Product cart = items.get(0);
		 String sql1="insert into cartdetails(item_no,item_name,quantity,price,category,email) values(?,?,?,?,?,?)";
		    jdbctemplate.update(sql1,item_no,cart.getItem_name(),cart.getQuantity(),cart.getPrice(),cart.getCategory(),useremail);
	}

	public  List<Cart> retrieveCart(int item_no) {
		String sql = "select * from cartdetails where item_no='"+item_no+"'; order by category asc";
		List<Cart> cartlist = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Cart.class));
		return cartlist;
		
	}


	public List<Cart> priceCalculation(String useremail) {
		String sql = "select * from cartdetails where email='"+useremail+"';";	
	    List<Cart> totalprice = jdbctemplate.query(sql, BeanPropertyRowMapper.newInstance(Cart.class));
		return totalprice;
		
	}

	

}

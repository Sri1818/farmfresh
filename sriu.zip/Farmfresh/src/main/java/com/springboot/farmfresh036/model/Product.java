package com.springboot.farmfresh036.model;

import org.springframework.stereotype.Component;





@Component
public class Product {

	private int item_no;
	private String item_name;
	private int quantity;
	private int price;
	private String category;

	public Product() {
		super();
	}

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "ProductList [item_no=" + item_no + ", item_name=" + item_name + ", quantity=" + quantity + ", price="
				+ price + ", category=" + category + "]";
	}

	public Product(int item_no, String item_name, int quantity, int price, String category) {
		super();
		this.item_no = item_no;
		this.item_name = item_name;
		this.quantity = quantity;
		this.price = price;
		this.category = category;
	}

}

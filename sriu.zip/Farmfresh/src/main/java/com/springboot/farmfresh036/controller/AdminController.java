package com.springboot.farmfresh036.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.farmfresh036.model.Product;
import com.springboot.farmfresh036.service.AdminService;
import com.springboot.farmfresh036.service.ProductService;

//Controller class for Admin

@Controller
public class AdminController {

	
	@Autowired
	ProductService productservice;
	@Autowired
	AdminService adminservice;
	
	@GetMapping("/adminlogin")
	public String showAdminLoginPage() {
		return "adminlogin";
	}

	@GetMapping("/productlist")
	public String showProductsPage(ModelMap model) {
		model.put("products", productservice.viewProducts());

		return "productlist";
	}
	
     //Post mapping for adminlogin validation
	
	@PostMapping("/adminlogin")
	public String showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password) {
		boolean isValidUser = adminservice.validateUser(name, password);

		if (!isValidUser) {
			model.put("errorMessage", "Invalid Credentials");
			return "adminlogin";
		}

		model.put("name", name);
		model.put("password", password);
		model.put("products", productservice.viewProducts());

		return "productlist";

	}

	@GetMapping("/additems")
	public String showAddProductsPage() {
		return "additems";
	}

	//add product details to the data base
	
	@PostMapping("/additems")
	public String AddProductsPage(Product products, @RequestParam String item_name, @RequestParam int quantity,
			@RequestParam int price, @RequestParam String category) {

		products.setItem_name(item_name);
		products.setQuantity(quantity);
		products.setPrice(price);
		products.setCategory(category);
		productservice.addProducts(products); //call the addProducts method in ProductDao class
		return "redirect:/productlist";
	}

	@GetMapping("/deleteproduct")
	public String deleteProductPage(@RequestParam int item_no) {
		productservice.deleteProduct(item_no);
		return "redirect:/productlist";
	}

	@GetMapping("/updateproduct")
	public String updateProductPage(ModelMap model, @RequestParam int item_no) {
		model.put("items", productservice.retrieveProductDetails(item_no));
		return "updateproduct";
	}

	//Update product in the existing product list 
	
	@PostMapping("/updateproduct")
	public String updateProduct(Product products, @RequestParam int item_no, @RequestParam String item_name,
			@RequestParam int quantity, @RequestParam int price, @RequestParam String category) {
		productservice.deleteProduct(item_no);
		products.setItem_name(item_name);
		products.setQuantity(quantity);
		products.setPrice(price);
		products.setCategory(category);
		productservice.update(item_no,item_name,quantity,price,category); //call the update methode in ProductDao class
		return "redirect:/productlist";

	}

	
	
}

package com.springboot.farmfresh036.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.springboot.farmfresh036.model.Cart;
import com.springboot.farmfresh036.model.Customer;
import com.springboot.farmfresh036.model.Product;
import com.springboot.farmfresh036.service.CustomerService;
import com.springboot.farmfresh036.service.ProductService;



@Controller
@SessionAttributes({"email","in"})
public class UserController {

	@Autowired
	CustomerService customerservice;
	@Autowired
	Customer customer;
	@Autowired
	ProductService productservice;
	@Autowired
	Product product;
	@Autowired
	Product products;
	@Autowired
	Cart cart;

	@GetMapping("/")
	public String showHome() {
		return "home";
	}
	@GetMapping("/login")
	public String showLoginPage() {
		return "login";
	}
	@GetMapping("/signup")
	public String showSignupPage() {
		return "signup";
	}
	@GetMapping("/farm")
	public String shoeFarmPage() {
		return "farm";
	}
	
	//Check the quantity with max value
	
	@GetMapping("/cart")
	public String showCartPage(ModelMap model, @RequestParam int item_no) {
		System.out.println(item_no);
		String useremail=(String) model.get("email");
		model.put("in",item_no);
		List<Cart> cartlist=productservice.retrieveCartDetails(item_no, useremail);
		System.out.println(item_no);
		if(cartlist.isEmpty())
		{
			productservice.insertcart(item_no,useremail);
			return "redirect:/displaymenu";
		}
		model.put("items", productservice.addProductDetails(item_no,useremail));
		
		if(cartlist.get(0).getQuantity()>9)
		{
			model.addAttribute("error", "Maximum Quantity Limit exceeded for itemno:"+item_no);
			return "redirect:/displaymenu";
		}
		
System.out.println(item_no);
		
		return "redirect:/displaymenu";
	}

	@PostMapping("/paymentdetails")
	public String showCardDetailstPage() {
		return "carddetails";
	}
	@GetMapping("/carddetails")
	public String showContactDetailsPage() {
		return "carddetails";
	}
	@PostMapping("/carddetails")
	public String showLastPage() {
		return "pay";
	}
		@GetMapping("/success")
		public String showfirstPage() {
			return "home";
	}
		
		@GetMapping("/displaymenu")
		public String showmenuPage(ModelMap model) {
		
		
			model.put("products", customerservice.viewProducts());
			
			return "displaymenu";
		}
		
		@GetMapping("/deleteproductpage")
		public String deleteProduct(@RequestParam int item_no,ModelMap model) {
			
			List<Product> productlist;
			productlist=productservice.retrieveProductDetails(item_no);
			product=productlist.get(0);
			int cquantity=product.getQuantity();
			System.out.println(cquantity);
			int cprice=product.getPrice();
			System.out.println(cprice);
			System.out.println(item_no);
			String useremail=(String) model.get("email");
			List<Cart> cartlist=productservice.retrieveCartDetails(item_no,useremail);
			if(cartlist.isEmpty())
			{
				return "ordersummary";
			}
			Cart cart1=cartlist.get(0);
			if(cart1.getQuantity()<=1)
			{
				System.out.println("delete1");
				productservice.deleteProduct(item_no,useremail);
				model.put("items", productservice.retrieveCartDetailsemail(useremail));
				model.addAttribute("totalprice",productservice.priceCalculation(useremail).stream().collect(Collectors.summingInt(n->n.getPrice())));
				
				return "ordersummary";
			}
			System.out.println("delete");
			productservice.deleteProductPage(item_no,cquantity,cprice,useremail);  //call the deleteProductPage method in ProductDao class
			model.put("items", productservice.retrieveCartDetailsemail(useremail));
			model.addAttribute("totalprice",productservice.priceCalculation(useremail).stream().collect(Collectors.summingInt(n->n.getPrice())));
			return "redirect:/ordersummary";
		}

		@GetMapping("/ordersummary")
		public String showOrderSummaryPage(ModelMap model) {
			String useremail=(String) model.get("email");
			int item_no= (int) model.get("in");
			//System.out.println(item_no);
			//System.out.println("hi");
			List<Cart> cartlist=productservice.retrieveCartDetails(item_no, useremail);
			if(cartlist.isEmpty())
			{
				return "ordersummary";
			}
			if(cartlist.get(0).getQuantity()>9)
			{
				model.put("items", productservice.retrieveCartDetailsemail(useremail));
				model.addAttribute("totalprice",productservice.priceCalculation(useremail).stream().collect(Collectors.summingInt(n->n.getPrice())));
				model.addAttribute("error", "Maximum Quantity Limit exceeded for itemno:"+item_no);
				return "ordersummary";
			}
			
			model.put("items", productservice.retrieveCartDetailsemail(useremail));
			model.addAttribute("totalprice",productservice.priceCalculation(useremail).stream().collect(Collectors.summingInt(n->n.getPrice())));
			return "ordersummary";
		}
	@PostMapping("/signup")
	public String DisplayMenupageForNewUser(Customer customer, @RequestParam String name,
			@RequestParam String email, @RequestParam String password, ModelMap model) {
		customer.setName(name);
		customer.setEmail(email);
		customer.setPassword(password);
		customerservice.createNewUser(customer);
		model.put("products", customerservice.viewProducts());
		return "login";
	}

	//validation for customer login
	
	@PostMapping("/login")
	public String DisplayMenupageForOldUser(ModelMap model, @RequestParam String email, @RequestParam String password) {

		List<Customer> cusdetail = customerservice.checkUser(email, password);
		if (cusdetail.isEmpty()) {
			model.put("errorMessage", "Invalid Credentials");
			return "login";
		}
		customer = cusdetail.get(0);
		if (!(customer.getPassword().equals(password))) {
			model.put("errorMessage", "Invalid Credentials");
			return "login";
		}
		model.put("products", customerservice.viewProducts());
		model.put("email",email);
		return "displaymenu";

	}
}

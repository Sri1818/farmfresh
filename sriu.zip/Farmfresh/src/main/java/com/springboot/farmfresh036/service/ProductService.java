package com.springboot.farmfresh036.service;

import java.util.List;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.farmfresh036.dao.ProductDao;
import com.springboot.farmfresh036.model.Cart;
import com.springboot.farmfresh036.model.Product;


@Service
public class ProductService {
	@Autowired
	ProductDao productDao;
	public List<Product> viewProducts() {
		return productDao.viewProducts();
	}
	public void addProducts(Product products) {
		productDao.addProducts(products);
	}
	public void deleteProduct(int item_no) {
		 productDao.deleteProduct(item_no);
	}
	public  List<Cart> retrieveCartDetails(int item_no,String useremail) {
		return productDao.retrieveCartDetails(item_no, useremail);
	}
	public List<Cart> deleteProductPage(int item_no,int cquantity,int cprice, String useremail) {
		return productDao.deleteProductPage(item_no, cquantity, cprice, useremail);
	}
	public void deleteProduct(int item_no, String useremail) {
		 productDao.deleteProduct(item_no, useremail);
	}
	public List<Product> retrieveProductDetails(int item_no) {
		return productDao.retrieveProductDetails(item_no);
	}
	public  List<Cart> retrieveCartDetailsemail(String useremail) {
		return productDao.retrieveCartDetailsemail( useremail);
	}
	public void update(int item_no,String item_name,int quantity,int price,String category) {
		 productDao.update( item_no, item_name, quantity, price, category);
	}
	public List<Product> addProductDetails(int item_no,String useremail) {
		return productDao.addProductDetails( item_no, useremail);
	}
	public  List<Cart> retrieveCart(int item_no) {
		return productDao.retrieveCart( item_no);
	}
	public List<Cart> priceCalculation(String useremail) {
		return productDao.priceCalculation(useremail);
	}
	public void insertcart(int item_no, String useremail) {
		productDao.insertcart(item_no,useremail);
		
	}
	
	
}

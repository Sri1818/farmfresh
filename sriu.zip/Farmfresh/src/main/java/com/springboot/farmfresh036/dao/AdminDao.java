package com.springboot.farmfresh036.dao;

import org.springframework.stereotype.Repository;

@Repository
public class AdminDao {
	public static boolean validateUser(String user_name, String password)
	{
		return user_name.equalsIgnoreCase("Srinath") && password.equalsIgnoreCase("Srinath@1821");
	}
}
